<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">

    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">

    <!-- Mapbox CSS -->
    <link href='https://api.tiles.mapbox.com/mapbox-gl-js/v0.51.0/mapbox-gl.css' rel='stylesheet' />

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
    <div id="app">
        

        

        
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <script src="https://cdn.pubnub.com/sdk/javascript/pubnub.4.21.6.min.js"></script>
    <!-- Mapbox JS -->
    <script src='https://api.tiles.mapbox.com/mapbox-gl-js/v0.51.0/mapbox-gl.js'></script>
        <script>
            $('form').on('submit', (e)=>{
                console.log($('form').serialize());
                // e.preventDefault();

                // $.ajax({
                //     url: '/login',
                //     dataType: 'JSON',
                //     type: 'POST',
                //     data:{email: $('#email').val(), password: $("#password").val()},
                //     success: (data)=>{
                //         console.log(data);
                //     }
                // });
            });
            $(document).ready(()=>{
                // mapboxgl.accessToken = 'pk.eyJ1IjoiYXhsY3V5dWdhbiIsImEiOiJjam9sMGc1dmEwaGR4M3BsczE1d3N0OXljIn0.iMI0eN2E39aTuNxtCkpY3Q';
                // var map = new mapboxgl.Map({
                //     container: 'map', // container id
                //     style: 'mapbox://styles/mapbox/streets-v9',
                //     center: [-96, 37.8], // starting position
                //     zoom: 3 // starting zoom
                // });
        
                // if (!mapboxgl.supported()) {
                //     alert('Your browser does not support Mapbox GL');
                // } else {
                //     console.log("SUPPORTED");
                //     // Add geolocate control to the map.
                //     map.addControl(new mapboxgl.GeolocateControl({
                //         positionOptions: {
                //             enableHighAccuracy: true
                //         },
                //         trackUserLocation: true
                //     }));
                // }
            });
        </script>

    <!-- Compiled and minified JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</body>
</html>
